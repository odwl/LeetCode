
import org.junit.Test;
import java.util.Random;

import static org.junit.Assert.*;

public class Tests {

    @Test()
    public void testMerge(){

        int[] array = {5, 1};
        int[] aux = new int[array.length];
        MergeSort.merge(array, aux, 0, 0, 1);

        assertTrue(aux[0] == 1);
        assertTrue(aux[1] == 5);
    }

    @Test()
    public void testMergeWith4(){

        int[] array = {4, 5, 1, 3};
        int[] aux = new int[array.length];
        MergeSort.merge(array, aux, 0, 1, 3);

        assertTrue(isArraySorted(aux));
    }

    @Test()
    public void testMergeWith4Bis(){

        int[] array = {1,3,4,5};
        int[] aux = new int[array.length];
        MergeSort.merge(array, aux, 0, 1, 3);

        assertTrue(isArraySorted(aux));
        assertTrue(aux[3] == 5);
    }


    @Test()
    public void testOneElement(){

        int[] array = {5};
        MergeSort.sort(array);

        assertTrue(array[0] == 5);
    }

    @Test()
    public void testTwoElement(){

        int[] array = {5, 1};
        MergeSort.sort(array);

        assertTrue(isArraySorted(array));
    }


    @Test()
    public void testMergeSort4(){

        int[] array = {1,3,4,5};
        MergeSort.sort(array);

        assertTrue(isArraySorted(array));
        assertTrue(array[3] == 5);
    }

    @Test()
    public void testMergeSortUnsorted(){

        int[] array = {1,5,4,3};
        int[] aux = new int[array.length];
        MergeSort.sort(array);

        assertTrue(isArraySorted(array));
        assertTrue(array[3] == 5);
    }

    @Test()
    public void testComplete(){

        int[] array = randomArray(10000);
        MergeSort.sort(array);

        assertTrue(isArraySorted(array));

    }


    private static boolean isArraySorted(int[] array){
        for(int i = 0 ; i < array.length -1; i++){
            if(array[i]>array[i+1])
                return false;

        }
        return true;
    }

    private static int[] randomArray(int size){
        int[] array = new int[size];
        Random rng = new Random();
        for(int i = 0 ; i < size ; i++){
            array[i]= rng.nextInt(Integer.MAX_VALUE);
        }
        return array;
    }

}
